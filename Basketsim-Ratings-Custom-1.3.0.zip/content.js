(function () {
  'use strict';
  const SKILLS = ['handling','quickness','passing','dribbling','rebounds','positioning','shooting','freethrows','defense'];
  const ALL_SKILLS = SKILLS.concat('experience');
  const POSITIONS = ['PG','SG','SF','PF','C'];
  const LABELS = {handling:['handling','ballhandling'],quickness:['quickness'],passing:['passing'],dribbling:['dribbling'],rebounds:['rebounds','rebounding'],positioning:['positioning'],shooting:['shooting'],freethrows:['freethrows','free throws'],defense:['defense'],experience:['experience']};
  const DEFAULTS = {
    PG:{handling:25,quickness:25,passing:25,dribbling:25},
    SG:{shooting:25,quickness:25,handling:25,defense:25},
    SF:{shooting:25,positioning:25,defense:25,passing:25},
    PF:{rebounds:25,positioning:25,defense:25,shooting:25},
    C:{rebounds:25,positioning:25,defense:25,freethrows:25}
  };
  const clone = value => JSON.parse(JSON.stringify(value));
  const clean = value => String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
  function blankConfig() { const out = {}; POSITIONS.forEach(pos => { out[pos] = {}; ALL_SKILLS.forEach(skill => { out[pos][skill] = 0; }); }); return out; }
  function defaultConfig() { const out = blankConfig(); POSITIONS.forEach(pos => Object.assign(out[pos], DEFAULTS[pos])); return out; }
  function normalizeConfig(input) { const out = blankConfig(); POSITIONS.forEach(pos => ALL_SKILLS.forEach(skill => { const n = Number(input?.[pos]?.[skill]); out[pos][skill] = Number.isInteger(n) && n >= 0 && n <= 100 ? n : 0; })); return out; }
  function parseScope(scope) {
    const skills = {};
    scope.querySelectorAll('tr').forEach(row => {
      const cells = [...row.querySelectorAll(':scope > td, :scope > th')];
      cells.forEach((cell, index) => {
        const label = clean(cell.textContent).replace(/:.*$/, '').trim();
        const key = ALL_SKILLS.find(skill => LABELS[skill].some(alias => label === alias || label.startsWith(alias + ':')));
        if (!key) return;
        const match = String(cell.textContent).match(/\(\s*(\d+(?:\.\d+)?)\s*\)/) || String(cells[index + 1]?.textContent || '').match(/\(\s*(\d+(?:\.\d+)?)\s*\)/);
        if (match) skills[key] = Number(match[1]);
      });
    });
    return skills;
  }
  function positionTotal(config, pos, experienceEnabled) { return ALL_SKILLS.reduce((sum, skill) => sum + (skill === 'experience' && !experienceEnabled ? 0 : config[pos][skill]), 0); }
  function calculate(skills, config, pos, experienceEnabled) {
    if (positionTotal(config, pos, experienceEnabled) !== 100) return null;
    return ALL_SKILLS.reduce((sum, skill) => {
      if (skill === 'experience' && !experienceEnabled) return sum;
      if (config[pos][skill] > 0 && !Number.isFinite(Number(skills[skill]))) return NaN;
      return sum + Number(skills[skill]) * config[pos][skill];
    }, 0) / 100;
  }
  function playerId(table, index) {
    const current = location.pathname.match(/^\/players\/(\d+)\/?$/);
    if (current) return current[1];
    const parent = table.parentElement;
    const html = parent ? parent.innerHTML.slice(0, parent.innerHTML.indexOf(table.outerHTML)) : '';
    const matches = [...html.matchAll(/\/players\/(\d+)/g)];
    return matches.length ? matches[matches.length - 1][1] : 'squad-' + index;
  }
  function supportedPath() { return /^\/players(?:\/\d+)?\/?$/.test(location.pathname); }
  function profilePath() { return /^\/players\/\d+\/?$/.test(location.pathname); }
  function classicIsOwned(node) { return !!node?.classList?.contains('bs-ratings-extension'); }
  function makeInput(root, pos, skill, state, update) {
    const label = document.createElement('label'); label.className = 'bsrc-skill'; label.textContent = skill;
    const wrap = document.createElement('span'); wrap.className = 'bsrc-percent';
    const input = document.createElement('input'); input.type = 'number'; input.min = '0'; input.max = '100'; input.step = '1'; input.inputMode = 'numeric'; input.dataset.bsrcInput = pos + ':' + skill;
    input.addEventListener('input', () => {
      if (input.value === '') { state.config[pos][skill] = 0; update(); return; }
      const parsed = Number(input.value);
      if (!Number.isInteger(parsed) || parsed < 0 || parsed > 100) { input.value = state.config[pos][skill]; return; }
      state.config[pos][skill] = parsed; update();
    });
    wrap.append(input, document.createTextNode('%')); label.append(wrap); root._bsrcInputs.push(input); return label;
  }
  function renderSettings(root, state, update) {
    root._bsrcInputs = [];
    let settings = root.querySelector('.bsrc-settings');
    if (!settings) { settings = document.createElement('div'); settings.className = 'bsrc-settings'; root.append(settings); }
    settings.replaceChildren();
    POSITIONS.forEach(pos => {
      const details = document.createElement('details'); details.className = 'bsrc-position';
      const summary = document.createElement('summary'); details.append(summary);
      const list = document.createElement('div'); list.className = 'bsrc-skill-list';
      ALL_SKILLS.forEach(skill => list.append(makeInput(root, pos, skill, state, update)));
      details.append(list); settings.append(details); root._bsrcDetails = root._bsrcDetails || []; root._bsrcDetails.push(details);
      details.addEventListener('toggle', () => update());
    });
    const reset = document.createElement('button'); reset.type = 'button'; reset.className = 'bsrc-reset'; reset.textContent = 'Reset defaults'; reset.addEventListener('click', () => { if (window.confirm('Reset all Custom Ratings weights to defaults?')) { state.config = defaultConfig(); update(); } }); settings.append(reset);
  }
  function updateRoot(root, skills, state, update) {
    let ratings = root.querySelector('.bsrc-ratings');
    if (!ratings) { ratings = document.createElement('div'); ratings.className = 'bsrc-ratings'; const title = document.createElement('strong'); title.className = 'bsrc-title'; title.textContent = 'Custom Ratings'; ratings.append(title); POSITIONS.forEach(pos => { const item = document.createElement('span'); item.className = 'bsrc-rating'; item.dataset.bsrcPosition = pos; const label = document.createElement('strong'); label.className = 'bsrc-position-label'; label.textContent = pos; const value = document.createElement('span'); value.className = 'bsrc-position-value'; item.append(label, document.createTextNode(' '), value); ratings.append(item); }); root.prepend(ratings); }
    POSITIONS.forEach(pos => { const item = ratings.querySelector('[data-bsrc-position="' + pos + '"]'); const total = positionTotal(state.config, pos, true); const calculated = calculate(skills, state.config, pos, true); const value = Number.isFinite(calculated) ? calculated : null; item.querySelector('.bsrc-position-value').textContent = value === null ? '—' : value.toFixed(2); item.title = value === null ? 'Configuration incomplete or unavailable: ' + total + '% / 100% (' + (100 - total) + '% remaining)' : ''; });
    const settings = document.querySelector('.bsrc-settings-root[data-bsrc-scope="' + root.dataset.bsrcScope + '"]'); if (settings && !settings.querySelector('.bsrc-settings')) renderSettings(settings, state, update);
    if (settings) { const details = settings.querySelectorAll('.bsrc-position'); details.forEach((details, index) => { const pos = POSITIONS[index]; const total = positionTotal(state.config, pos, true); const ready = total === 100; details.querySelector('summary').textContent = (details.open ? '▼ ' : '▶ ') + pos + ' | Total: ' + total + '% | ' + (ready ? 'Ready' : (100 - total) + '% remaining'); }); settings.querySelectorAll('[data-bsrc-input]').forEach(input => { if (document.activeElement === input) return; const [pos, skill] = input.dataset.bsrcInput.split(':'); input.value = state.config[pos][skill]; }); }
  }
  function start() {
    if (!supportedPath()) return;
    const roots = new Map(); let observer; let scheduled = false; const storage = typeof chrome !== 'undefined' ? chrome.storage?.local : null;
    function stateConfig(value) { return value.bsrcExperience ? value.bsrcConfigsOn : value.bsrcConfigsOff; }
    function boot(saved) {
      saved = saved || {};
      const migrated = saved.bsrcConfigV2 ? normalizeConfig(saved.bsrcConfigV2) : normalizeConfig(saved.bsrcExperience ? (saved.bsrcConfigsOn || defaultConfig()) : (saved.bsrcConfigsOff || defaultConfig()));
      const state = { config: migrated };
      function persist() { if (!storage?.set) return; try { storage.set({ bsrcConfigV2: state.config, bsrcMigrationV2: true }); } catch (error) { console.warn('[Basketsim Custom] storage save failed', error); } }
      function renderAll() { roots.forEach(entry => updateRoot(entry.root, entry.skills, state, updateAll)); }
      function updateAll() { persist(); renderAll(); }
      function inject() {
        const tables = profilePath() ? [...document.querySelectorAll('table.player-skills')] : [...document.querySelectorAll('table.squad-skills')];
        if (!tables.length) return;
        const scope = profilePath() ? 'profile-' + (location.pathname.match(/\/players\/(\d+)/)?.[1] || 'current') : 'squad';
        document.querySelectorAll('.bsrc-root[data-bsrc-scope]:not([data-bsrc-scope="' + scope + '"]),.bsrc-settings-root[data-bsrc-scope]:not([data-bsrc-scope="' + scope + '"])').forEach(node => node.remove());
        [...roots.keys()].forEach(id => { if (roots.get(id).root.dataset.bsrcScope !== scope) roots.delete(id); });
        const duplicateSettings = [...document.querySelectorAll('.bsrc-settings-root[data-bsrc-scope="' + scope + '"]')]; duplicateSettings.slice(1).forEach(node => node.remove()); let settings = duplicateSettings[0];
        if (!settings) { settings = document.createElement('div'); settings.className = 'bsrc-settings-root'; settings.dataset.bsrcScope = scope; const main = document.querySelector('#content #main,#main,#content,main') || document.body; main.append(settings); }
        const seen = new Set();
        tables.forEach((table, index) => {
          const id = playerId(table, index); seen.add(id); const duplicateRoots = [...document.querySelectorAll('.bsrc-root[data-bsrc-player-id="' + id + '"]')]; duplicateRoots.slice(1).forEach(node => node.remove()); let root = duplicateRoots[0];
          if (!root) { root = document.createElement('div'); root.className = 'bsrc-root'; root.dataset.bsrcPlayerId = id; root.dataset.bsrcScope = scope; const classic = table.nextElementSibling && classicIsOwned(table.nextElementSibling) ? table.nextElementSibling : null; (classic || table).insertAdjacentElement('afterend', root); }
          root.dataset.bsrcScope = scope; const skills = parseScope(table); roots.set(id, {root, settings, skills}); updateRoot(root, skills, state, updateAll);
        });
        [...roots.keys()].filter(id => !seen.has(id)).forEach(id => roots.delete(id));
      }
      function schedule(records) { if (records && records.length && records.every(record => record.target.closest?.('.bsrc-root'))) return; if (scheduled) return; scheduled = true; requestAnimationFrame(() => { scheduled = false; inject(); }); }
      inject(); observer = new MutationObserver(schedule); observer.observe(document.body, {childList:true, subtree:true});
      window.BasketsimRatingsCustom = {parseScope, calculate, inject};
      window.addEventListener('popstate', schedule); window.addEventListener('hashchange', schedule);
      chrome.storage?.onChanged?.addListener((changes, area) => { if (area === 'local' && changes.bsrcConfigV2) { state.config = normalizeConfig(changes.bsrcConfigV2.newValue); renderAll(); } });
      persist();
    }
    let started = false;
    const bootOnce = saved => { if (started) return; started = true; boot(saved); };
    try { if (storage?.get) storage.get({ bsrcConfigV2:null, bsrcMigrationV2:false, bsrcExperience:false, bsrcConfigsOff:defaultConfig(), bsrcConfigsOn:defaultConfig() }, bootOnce); else bootOnce(null); } catch (error) { console.warn('[Basketsim Custom] storage load failed', error); bootOnce(null); }
  }
  start();
})();
