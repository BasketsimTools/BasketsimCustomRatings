import fs from 'node:fs';
import assert from 'node:assert/strict';

const [sourcePath, manifestPath, playersPath, profilePath, marketPath] = process.argv.slice(2);
assert(sourcePath && manifestPath && playersPath && profilePath && marketPath, 'pass packaged content.js, manifest.json and three fixtures');
const source = fs.readFileSync(sourcePath, 'utf8');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const players = fs.readFileSync(playersPath, 'utf8');
const profile = fs.readFileSync(profilePath, 'utf8');
const market = fs.readFileSync(marketPath, 'utf8');

assert.equal(manifest.manifest_version, 3);
assert.equal(manifest.content_scripts[0].matches.length, 4);
assert.equal(manifest.content_scripts[0].matches.some(match => match.includes('/market')), false);
assert.equal((manifest.content_scripts[0].matches.join(' ')).includes('market'), false);
assert.match(source, /table\.player-skills/);
assert.match(source, /table\.squad-skills/);
assert.match(source, /profilePath\(\)/);
assert.match(source, /bsrcConfigV2/);
assert.match(source, /storage\?\.onChanged/);
assert.doesNotMatch(source, /bsrc-experience-toggle|Include Experience in ratings/);
assert.match(source, /bs-ratings-extension/);
assert.doesNotMatch(source, /className\s*=\s*['"]bs-ratings-extension/);
assert.match(source, /classicIsOwned/);
assert.match(source, /\(classic \|\| table\)\.insertAdjacentElement\('afterend', root\)/);
assert.equal((players.match(/class="squad-skills"/g) || []).length, 12);
assert.equal((profile.match(/class="player-skills"/g) || []).length, 1);
assert.equal((market.match(/class="market-result-skills"/g) || []).length, 8);
assert.equal((source.match(/\.bsrc-root/g) || []).length > 0, true);
assert.equal((source.match(/\.bsrc-settings-root/g) || []).length > 0, true);

function weighted(skills, weights) { const total = Object.values(weights).reduce((a, b) => a + b, 0); return total === 100 ? Object.entries(weights).reduce((sum, [key, weight]) => sum + skills[key] * weight, 0) / 100 : null; }
assert.equal(weighted({handling:8,quickness:10,passing:12},{handling:30,quickness:30,passing:40}), 10.2);
assert.equal(weighted({handling:8},{handling:115}), null);
assert.equal(weighted({handling:8},{handling:40}), null);
assert.equal(weighted({handling:8,experience:3},{handling:80,experience:20}), 7);
assert.equal(weighted({handling:8},{handling:80,experience:20}), NaN);
console.log('Packaged manifest/source and supplied fixture regression checks passed. Fixture checks are structural; live Chrome rendering is not exercised by this Node test.');
