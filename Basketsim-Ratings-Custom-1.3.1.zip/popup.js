// Settings are managed inline below each Basketsim player.
