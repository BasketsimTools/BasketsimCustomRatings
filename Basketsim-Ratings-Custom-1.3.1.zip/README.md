# Basketsim Ratings Custom 1.2.0

Private Manifest V3 build for Basketsim squad pages at `/players` and individual profiles at `/players/{id}`. The content script is registered on the `/players*` path and performs the narrower runtime check, so `/market`, market results and unrelated pages remain unchanged.

Custom uses one results bar below every squad skills table or the individual profile skills table, plus one shared settings panel at the bottom of the relevant page content. All ten skills, including Experience, are regular integer percentage inputs. Draft totals may be above or below 100%; a rating is shown only at exactly 100%. Settings are shared and saved in `chrome.storage.local` under `bsrcConfigV2`.

Migration: on first run, `bsrcConfigV2` is created from the previously active `bsrcConfigsOn` or `bsrcConfigsOff` configuration, based on the legacy `bsrcExperience` flag. Legacy keys are retained and not overwritten or deleted. The migration is idempotent.

Custom owns only `bsrc-*` elements and never creates or edits Classic `.bs-ratings-extension` elements.
