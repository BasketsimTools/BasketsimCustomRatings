(function () {
  'use strict';
  const SKILLS = ['handling','quickness','passing','dribbling','rebounds','positioning','shooting','freethrows','defense'];
  const ALL_SKILLS = SKILLS.concat('experience');
  const POSITIONS = ['PG','SG','SF','PF','C'];
  const LABELS = {handling:['handling','ballhandling'],quickness:['quickness'],passing:['passing'],dribbling:['dribbling'],rebounds:['rebounds','rebounding'],positioning:['positioning'],shooting:['shooting'],freethrows:['freethrows','free throws'],defense:['defense'],experience:['experience']};
  const DEFAULTS = {
    PG:{handling:25,quickness:25,passing:25,dribbling:25},
    SG:{shooting:25,quickness:25,handling:25,defense:25},
    SF:{shooting:25,positioning:25,defense:25,passing:25},
    PF:{rebounds:25,positioning:25,defense:25,shooting:25},
    C:{rebounds:25,positioning:25,defense:25,freethrows:25}
  };
  const clone = value => JSON.parse(JSON.stringify(value));
  const clean = value => String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
  function blankConfig() { const out = {}; POSITIONS.forEach(pos => { out[pos] = {}; ALL_SKILLS.forEach(skill => { out[pos][skill] = 0; }); }); return out; }
  function defaultConfig() { const out = blankConfig(); POSITIONS.forEach(pos => Object.assign(out[pos], DEFAULTS[pos])); return out; }
  function normalizeConfig(input) { const out = blankConfig(); POSITIONS.forEach(pos => ALL_SKILLS.forEach(skill => { const n = Number(input?.[pos]?.[skill]); out[pos][skill] = Number.isInteger(n) && n >= 0 && n <= 100 ? n : 0; })); return out; }
  function parseScope(scope) {
    const skills = {};
    scope.querySelectorAll('tr').forEach(row => {
      const cells = [...row.querySelectorAll(':scope > td, :scope > th')];
      cells.forEach((cell, index) => {
        const label = clean(cell.textContent).replace(/:.*$/, '').trim();
        const key = ALL_SKILLS.find(skill => LABELS[skill].some(alias => label === alias || label.startsWith(alias + ':')));
        if (!key) return;
        const match = String(cell.textContent).match(/\(\s*(\d+(?:\.\d+)?)\s*\)/) || String(cells[index + 1]?.textContent || '').match(/\(\s*(\d+(?:\.\d+)?)\s*\)/);
        if (match) skills[key] = Number(match[1]);
      });
    });
    return skills;
  }
  function positionTotal(config, pos, experienceEnabled) { return ALL_SKILLS.reduce((sum, skill) => sum + (skill === 'experience' && !experienceEnabled ? 0 : config[pos][skill]), 0); }
  function calculate(skills, config, pos, experienceEnabled) {
    if (positionTotal(config, pos, experienceEnabled) !== 100) return null;
    return ALL_SKILLS.reduce((sum, skill) => {
      if (skill === 'experience' && !experienceEnabled) return sum;
      return sum + (Number(skills[skill]) || 0) * config[pos][skill];
    }, 0) / 100;
  }
  function playerId(table, index) {
    const current = location.pathname.match(/^\/players\/(\d+)\/?$/);
    if (current) return current[1];
    const parent = table.parentElement;
    const html = parent ? parent.innerHTML.slice(0, parent.innerHTML.indexOf(table.outerHTML)) : '';
    const matches = [...html.matchAll(/\/players\/(\d+)/g)];
    return matches.length ? matches[matches.length - 1][1] : 'squad-' + index;
  }
  function supportedPath() { return /^\/players(?:\/\d+)?\/?$/.test(location.pathname); }
  function makeInput(root, pos, skill, state, update) {
    const label = document.createElement('label'); label.className = 'bsrc-skill'; label.textContent = skill;
    const wrap = document.createElement('span'); wrap.className = 'bsrc-percent';
    const input = document.createElement('input'); input.type = 'number'; input.min = '0'; input.max = '100'; input.step = '1'; input.inputMode = 'numeric'; input.dataset.bsrcInput = pos + ':' + skill;
    input.addEventListener('input', () => {
      const parsed = Number(input.value); const other = positionTotal(state.config, pos, state.experience) - state.config[pos][skill];
      if (!Number.isInteger(parsed) || parsed < 0) { input.value = state.config[pos][skill]; return; }
      state.config[pos][skill] = Math.min(100, Math.max(0, Math.min(parsed, 100 - other))); input.value = state.config[pos][skill]; update();
    });
    wrap.append(input, document.createTextNode('%')); label.append(wrap); root._bsrcInputs.push(input); return label;
  }
  function renderSettings(root, state, update) {
    root._bsrcInputs = [];
    let settings = root.querySelector('.bsrc-settings');
    if (!settings) { settings = document.createElement('div'); settings.className = 'bsrc-settings'; root.append(settings); }
    settings.replaceChildren();
    const expLabel = document.createElement('label'); expLabel.className = 'bsrc-experience-toggle';
    const exp = document.createElement('input'); exp.type = 'checkbox'; exp.checked = state.experience; exp.addEventListener('change', () => { state.configs[state.experience ? 'off' : 'on'] = state.config; state.experience = exp.checked; state.config = state.configs[state.experience ? 'on' : 'off']; document.querySelectorAll('.bsrc-settings').forEach(node => node.remove()); update(); });
    expLabel.append(exp, document.createTextNode(' Include Experience in ratings')); settings.append(expLabel);
    POSITIONS.forEach(pos => {
      const details = document.createElement('details'); details.className = 'bsrc-position';
      const summary = document.createElement('summary'); details.append(summary);
      const list = document.createElement('div'); list.className = 'bsrc-skill-list';
      ALL_SKILLS.filter(skill => state.experience || skill !== 'experience').forEach(skill => list.append(makeInput(root, pos, skill, state, update)));
      details.append(list); settings.append(details); root._bsrcDetails = root._bsrcDetails || []; root._bsrcDetails.push(details);
      details.addEventListener('toggle', () => update());
    });
    const reset = document.createElement('button'); reset.type = 'button'; reset.className = 'bsrc-reset'; reset.textContent = 'Reset defaults'; reset.addEventListener('click', () => { if (window.confirm('Reset all Custom Ratings weights to defaults?')) { state.config = state.experience ? clone(state.config) : defaultConfig(); if (state.experience) state.config = defaultConfig(); update(); } }); settings.append(reset);
  }
  function updateRoot(root, skills, state, update) {
    let ratings = root.querySelector('.bsrc-ratings');
    if (!ratings) { ratings = document.createElement('div'); ratings.className = 'bsrc-ratings'; ratings.append(document.createTextNode('Custom Ratings')); POSITIONS.forEach(pos => { const item = document.createElement('span'); item.className = 'bsrc-rating'; item.dataset.bsrcPosition = pos; ratings.append(item); }); root.prepend(ratings); }
    POSITIONS.forEach(pos => { const item = ratings.querySelector('[data-bsrc-position="' + pos + '"]'); const total = positionTotal(state.config, pos, state.experience); const value = calculate(skills, state.config, pos, state.experience); item.textContent = pos + ' ' + (value === null ? '—' : value.toFixed(2)); item.title = value === null ? 'Configuration incomplete: ' + total + '% / 100% (' + (100 - total) + '% remaining)' : ''; });
    if (!root.querySelector('.bsrc-settings')) renderSettings(root, state, update);
    const details = root.querySelectorAll('.bsrc-position'); details.forEach((details, index) => { const pos = POSITIONS[index]; const total = positionTotal(state.config, pos, state.experience); const ready = total === 100; details.querySelector('summary').textContent = (details.open ? '▼ ' : '▶ ') + pos + ' | Total: ' + total + '% | ' + (ready ? 'Ready' : (100 - total) + '% remaining'); });
    root.querySelectorAll('[data-bsrc-input]').forEach(input => { const [pos, skill] = input.dataset.bsrcInput.split(':'); input.value = state.config[pos][skill]; });
  }
  function start() {
    if (!supportedPath()) return;
    const roots = new Map(); let observer; let scheduled = false;
    function stateConfig(value) { return value.bsrcExperience ? value.bsrcConfigsOn : value.bsrcConfigsOff; }
    function boot(saved) {
      saved = saved || {};
      const state = { experience: !!saved.bsrcExperience, configs: {off:normalizeConfig(saved.bsrcConfigsOff || defaultConfig()), on:normalizeConfig(saved.bsrcConfigsOn || defaultConfig())}, config: null };
      state.config = state.configs[state.experience ? 'on' : 'off'];
      function persist() { state.configs[state.experience ? 'on' : 'off'] = state.config; chrome.storage.local.set({ bsrcExperience:state.experience, bsrcConfigsOff:state.configs.off, bsrcConfigsOn:state.configs.on }); }
      function updateAll() { persist(); roots.forEach(entry => updateRoot(entry.root, entry.skills, state, updateAll)); }
      function inject() {
        if (!supportedPath()) return;
        document.querySelectorAll('table.squad-skills, table.player-skills').forEach((table, index) => {
          const id = playerId(table, index); let root = document.querySelector('.bsrc-root[data-bsrc-player-id="' + id + '"]');
          if (!root) { root = document.createElement('div'); root.className = 'bsrc-root'; root.dataset.bsrcPlayerId = id; table.insertAdjacentElement('afterend', root); }
          const skills = parseScope(table); roots.set(id, {root, skills}); updateRoot(root, skills, state, updateAll);
        });
      }
      function schedule(records) { if (records && records.length && records.every(record => record.target.closest?.('.bsrc-root'))) return; if (scheduled) return; scheduled = true; requestAnimationFrame(() => { scheduled = false; inject(); }); }
      inject(); observer = new MutationObserver(schedule); observer.observe(document.body, {childList:true, subtree:true});
      window.BasketsimRatingsCustom = {parseScope, calculate, inject};
    }
    let started = false;
    const bootOnce = saved => { if (started) return; started = true; boot(saved); };
    try { if (chrome.storage?.local?.get) chrome.storage.local.get({ bsrcExperience:false, bsrcConfigsOff:defaultConfig(), bsrcConfigsOn:defaultConfig() }, bootOnce); else bootOnce(null); } catch (error) { bootOnce(null); }
  }
  start();
})();
