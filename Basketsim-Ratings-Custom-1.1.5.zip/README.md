# Basketsim Ratings Custom 1.1.0

Private Manifest V3 build for Basketsim `https://www.basketsim.net/players` and individual `/players/{id}` profiles only.

Load the ZIP through Chrome Developer Mode. The compact Custom Ratings row and collapsed position settings appear below each player's skills table. Weights are integer percentages from 0 to 100; a position is rated only when its active total is exactly 100%. Experience has separate saved configurations for enabled and disabled modes. Settings are shared across all visible players and saved automatically.

This build does not select, create, move, remove, or modify Classic Ratings elements.
