import fs from 'node:fs'; import assert from 'node:assert/strict';
const calc=(skills,w)=>{let n=0,d=0;for(const k of Object.keys(w)){const x=Number(skills[k]);const z=Number(w[k])||0;if(z>0&&Number.isFinite(x)){n+=x*z;d+=z}}return d?n/d:null};
assert.equal(calc({handling:8,quickness:8,passing:4,defense:8},{handling:1,quickness:1,passing:1,defense:1}),7);
assert.equal(calc({handling:8},{handling:0}),null);
assert.equal(calc({handling:8},{handling:1,experience:1}),8); // missing Experience is excluded, not coerced to zero
const fixtures=process.argv.slice(2); assert.equal(fixtures.length,3,'pass Players, profile and Market fixture paths');
const text=fixtures.map(f=>fs.readFileSync(f,'utf8')); assert(text[0].includes('squad-skills')); assert(text[1].includes('player-skills')); assert(text[2].includes('market-result-skills'));
for(const t of text.map(x=>x.toLowerCase())) for(const label of ['handling','quickness','passing','dribbling','rebound','positioning','shooting','defense']) assert(t.includes(label),`missing ${label}`);
console.log('All calculation and fixture checks passed.');
